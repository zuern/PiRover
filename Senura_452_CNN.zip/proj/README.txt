the training_data folder has folders called cars and not cars 
which is used by the trainpl.py to build the models the models are initially given but might be needed to be rerun.